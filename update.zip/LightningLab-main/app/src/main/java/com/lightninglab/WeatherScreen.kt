package com.lightninglab

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.expandVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.util.Locale
import kotlin.math.roundToInt

private fun kindRes(k: CloudAnalysis.Kind) = when (k) {
    CloudAnalysis.Kind.CLEAR -> R.string.kind_clear
    CloudAnalysis.Kind.THIN_STREAKS -> R.string.kind_thin
    CloudAnalysis.Kind.CUMULIFORM -> R.string.kind_cumuliform
    CloudAnalysis.Kind.UNIFORM_LAYER -> R.string.kind_layer
    CloudAnalysis.Kind.DARK_OVERCAST -> R.string.kind_dark
    CloudAnalysis.Kind.MIXED -> R.string.kind_mixed
}

private fun frameQualityRes(q: CloudAnalysis.FrameQuality) = when (q) {
    CloudAnalysis.FrameQuality.GOOD -> R.string.wx_frame_good
    CloudAnalysis.FrameQuality.CHECK_FRAME -> R.string.wx_frame_check
    CloudAnalysis.FrameQuality.LOW_SKY_CONTENT -> R.string.wx_frame_low_sky
}

@Composable
fun WeatherScreen(vm: MainVM) {
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u ->
        if (u != null) vm.analyzeSky(u)
    }
    LaunchedEffect(Unit) { vm.initModel() }
    Column(Modifier.fillMaxSize()) {
        TopBar(stringResource(R.string.weather_title), actions = {
            Surface(shape = CircleShape, color = if (vm.modelReady) Color(0xFF12382F) else Storm.surfaceTop,
                border = BorderStroke(1.dp, if (vm.modelReady) Color(0xFF287A63) else Storm.hairline)) {
                Row(Modifier.padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(Modifier.size(7.dp).clip(CircleShape).background(if (vm.modelReady) Color(0xFF55D6A7) else Storm.muted))
                    Text(stringResource(if (vm.modelReady) R.string.wx_model_chip_loaded else R.string.wx_model_chip_demo),
                        style = MaterialTheme.typography.labelSmall,
                        color = if (vm.modelReady) Color(0xFF8BE2C4) else Storm.muted)
                }
            }
            Spacer(Modifier.width(8.dp))
        })
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)) {
            // Premium atmospheric header
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF1D3552), Color(0xFF142234), Color(0xFF101722))))
                .padding(18.dp)) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFF294766)) {
                            Box(Modifier.size(44.dp), contentAlignment = Alignment.Center) {
                                AppIcon(Ic.CLOUD, Color(0xFFB9DFFF), Modifier.size(27.dp), filled = true)
                            }
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(stringResource(R.string.wx_workspace_title), style = MaterialTheme.typography.titleLarge,
                                color = Color.White, fontWeight = FontWeight.Bold)
                            Text(stringResource(R.string.wx_workspace_subtitle), style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFFB6C9DC))
                        }
                        Text("AI", color = Storm.bolt, style = MaterialTheme.typography.labelLarge)
                    }
                    Text(stringResource(R.string.wx_workspace_desc), style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFFE0EAF5))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        MetaPill(stringResource(R.string.wx_offline_pill), Color(0xFF183F3A), Color(0xFF8BE2C4))
                        MetaPill(stringResource(R.string.wx_image_pill), Color(0xFF263B55), Color(0xFFB9DFFF))
                    }
                }
            }

            // Upload / analyze action
            Surface(shape = RoundedCornerShape(22.dp), color = Storm.surfaceHi,
                border = BorderStroke(1.dp, Storm.outline.copy(alpha = .55f))) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(stringResource(R.string.wx_start_title), style = MaterialTheme.typography.titleMedium)
                            Text(stringResource(R.string.wx_hint), style = MaterialTheme.typography.bodySmall, color = Storm.muted)
                        }
                        Surface(shape = CircleShape, color = Storm.boltDim) {
                            Box(Modifier.size(42.dp), contentAlignment = Alignment.Center) {
                                AppIcon(Ic.PHOTO, Storm.bolt, Modifier.size(22.dp))
                            }
                        }
                    }
                    Button(onClick = { pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)) {
                        AppIcon(Ic.CLOUD, Storm.onBolt, Modifier.size(20.dp), filled = true)
                        Spacer(Modifier.width(9.dp))
                        Text(stringResource(R.string.pick_sky), style = MaterialTheme.typography.labelLarge)
                    }
                }
            }

            vm.wxBitmap?.let { bmp ->
                Surface(shape = RoundedCornerShape(22.dp), color = Storm.surfaceHi,
                    border = BorderStroke(1.dp, Storm.hairline)) {
                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Image(bmp.asImageBitmap(), null, Modifier.fillMaxWidth().heightIn(max = 280.dp)
                            .clip(RoundedCornerShape(15.dp)))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(stringResource(R.string.wx_analysis_result), style = MaterialTheme.typography.titleMedium,
                                modifier = Modifier.weight(1f))
                            MetaPill(stringResource(R.string.wx_image_analyzed), Color(0xFF183F3A), Color(0xFF8BE2C4))
                        }
                    }
                }
            }

            vm.wx?.let { r ->
                AnimatedVisibility(visible = true, enter = fadeIn() + expandVertically()) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        // Main result metrics
                        Surface(shape = RoundedCornerShape(22.dp), color = Storm.surfaceHi,
                            border = BorderStroke(1.dp, Storm.hairline)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                Text(stringResource(R.string.wx_cloud_state), style = MaterialTheme.typography.titleMedium)
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    MetricTile(stringResource(R.string.wx_cover_metric), "${(r.cover * 100).roundToInt()}%",
                                        stringResource(R.string.wx_cover_sub), Modifier.weight(1f), Storm.arc)
                                    MetricTile(stringResource(R.string.wx_oktas_metric), "${r.oktas}/8",
                                        stringResource(R.string.wx_oktas_sub), Modifier.weight(1f), Storm.bolt)
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    MetricTile(stringResource(R.string.wx_texture_metric), String.format(Locale.US, "%.1f", r.texture),
                                        stringResource(R.string.wx_texture_sub), Modifier.weight(1f), Color(0xFF9C9BFF))
                                    MetricTile(stringResource(R.string.wx_appearance_metric), stringResource(kindRes(r.kind)),
                                        stringResource(R.string.wx_appearance_sub), Modifier.weight(1f), Color(0xFF67C9B5))
                                }
                                Text(stringResource(frameQualityRes(r.frameQuality)), style = MaterialTheme.typography.bodySmall,
                                    color = if (r.frameQuality == CloudAnalysis.FrameQuality.GOOD) Color(0xFF8BE2C4) else MaterialTheme.colorScheme.error)
                                Text(stringResource(R.string.wx_sky_fraction, (r.skyLikeFraction * 100).roundToInt()),
                                    style = MaterialTheme.typography.labelSmall, color = Storm.muted)
                            }
                        }

                        // AI model output
                        Surface(shape = RoundedCornerShape(22.dp), color = Storm.surfaceHi,
                            border = BorderStroke(1.dp, if (vm.modelReady) Color(0xFF287A63) else Storm.hairline)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(stringResource(R.string.wx_ai_result_title), style = MaterialTheme.typography.titleMedium,
                                        modifier = Modifier.weight(1f))
                                    MetaPill(stringResource(if (vm.modelReady) R.string.wx_ai_active else R.string.wx_ai_fallback),
                                        if (vm.modelReady) Color(0xFF183F3A) else Storm.surfaceTop,
                                        if (vm.modelReady) Color(0xFF8BE2C4) else Storm.muted)
                                }
                                if (vm.topK.isNotEmpty()) {
                                    vm.topK.forEachIndexed { i, (code, score) ->
                                        ScoreRow(CloudInfo.genusName(code), score, i == 0)
                                    }
                                    Text(stringResource(R.string.wx_model_score_note), style = MaterialTheme.typography.bodySmall,
                                        color = Storm.muted)
                                    Text(stringResource(R.string.wx_model_domain_note), style = MaterialTheme.typography.bodySmall,
                                        color = Storm.muted)
                                } else {
                                    Text(stringResource(R.string.wx_model_not_ready), style = MaterialTheme.typography.bodySmall,
                                        color = Storm.muted)
                                    Text(stringResource(R.string.wx_heuristic_only_note), style = MaterialTheme.typography.bodySmall,
                                        color = Storm.muted)
                                }
                            }
                        }

                        // Human review and correction
                        Surface(shape = RoundedCornerShape(22.dp), color = Storm.surfaceHi,
                            border = BorderStroke(1.dp, Storm.hairline)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text(stringResource(R.string.wx_review_title), style = MaterialTheme.typography.titleMedium)
                                Text(stringResource(R.string.wx_genus_pick), style = MaterialTheme.typography.bodySmall, color = Storm.muted)
                                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                    CloudInfo.genusCodes.forEach { c ->
                                        FilterChip(selected = vm.genus == c, onClick = { vm.genus = c },
                                            label = { Text(c) }, shape = RoundedCornerShape(12.dp))
                                    }
                                }
                                Text(stringResource(R.string.wx_features_pick), style = MaterialTheme.typography.bodySmall, color = Storm.muted)
                                listOf(CloudInfo.supplementary.take(8), CloudInfo.supplementary.drop(8),
                                    CloudInfo.speciesVarieties.take(6), CloudInfo.speciesVarieties.drop(6)).forEach { row ->
                                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        row.forEach { f -> FilterChip(f in vm.features, { vm.toggleFeature(f) }, label = { Text(f) }) }
                                    }
                                }
                                Text(stringResource(R.string.wx_manual_tags_note), style = MaterialTheme.typography.bodySmall,
                                    color = Storm.muted)
                            }
                        }
                        Button(onClick = { vm.saveInfographic() }, enabled = !vm.busy,
                            modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)) {
                            AppIcon(Ic.EXPORT, Storm.onBolt, Modifier.size(20.dp))
                            Spacer(Modifier.width(8.dp)); Text(stringResource(R.string.save_infographic))
                        }
                    }
                }
            }
            InfoText(vm)
            Text(stringResource(R.string.wx_disclaimer), style = MaterialTheme.typography.bodySmall, color = Storm.muted)
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun MetaPill(text: String, bg: Color, fg: Color) {
    Surface(shape = CircleShape, color = bg) {
        Text(text, Modifier.padding(horizontal = 10.dp, vertical = 6.dp), color = fg,
            style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun MetricTile(label: String, value: String, detail: String, modifier: Modifier = Modifier, accent: Color) {
    Surface(modifier, shape = RoundedCornerShape(16.dp), color = Storm.surface,
        border = BorderStroke(1.dp, Storm.hairline)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = Storm.muted)
            Text(value, style = MaterialTheme.typography.titleLarge, color = accent, fontWeight = FontWeight.Bold)
            Text(detail, style = MaterialTheme.typography.labelSmall, color = Storm.muted)
        }
    }
}

@Composable
private fun ScoreRow(label: String, score: Float, highlighted: Boolean) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, style = MaterialTheme.typography.bodyMedium, fontWeight = if (highlighted) FontWeight.Bold else FontWeight.Normal,
                modifier = Modifier.weight(1f))
            Text("${(score * 100).roundToInt()}%", style = MaterialTheme.typography.labelLarge,
                color = if (highlighted) Storm.bolt else Storm.muted)
        }
        Box(Modifier.fillMaxWidth().height(7.dp).clip(CircleShape).background(Storm.surface)) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(score.coerceIn(0f, 1f)).clip(CircleShape)
                .background(if (highlighted) Brush.horizontalGradient(listOf(Storm.arc, Storm.bolt))
                    else Brush.horizontalGradient(listOf(Storm.arc.copy(alpha = .55f), Storm.arc.copy(alpha = .9f)))))
        }
    }
}
