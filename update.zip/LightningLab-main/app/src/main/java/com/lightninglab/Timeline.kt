package com.lightninglab

/**
 * Reserved for the next dedicated timeline module. The active editor timeline is currently
 * implemented in Screens.kt and backed by MainVM. Kept as a valid Kotlin source file so the
 * parked r12 implementation can be restored without breaking the current application build.
 */
