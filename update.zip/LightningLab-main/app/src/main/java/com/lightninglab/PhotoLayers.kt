package com.lightninglab

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint

/** Non-destructive, independently editable photo overlay layer. Coordinates are normalized to canvas size. */
data class PhotoTextLayer(
    val id: Long,
    val name: String,
    val text: String,
    val x: Float = 0.5f,
    val y: Float = 0.5f,
    val size: Float = 0.075f,
    val color: Int = 0xFFFFFFFF.toInt(),
    val opacity: Float = 1f,
    val visible: Boolean = true,
    val bold: Boolean = true
)

object PhotoLayers {
    /** Returns a new bitmap; input remains owned by caller. */
    fun render(base: Bitmap, layers: List<PhotoTextLayer>): Bitmap {
        if (layers.none { it.visible && it.text.isNotBlank() }) return base
        val out = base.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(out)
        layers.filter { it.visible && it.text.isNotBlank() }.forEach { layer ->
            val sizePx = (base.width * layer.size).coerceIn(12f, base.width * 0.3f)
            val paint = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
                color = layer.color
                alpha = (255 * layer.opacity.coerceIn(0f, 1f)).toInt()
                textSize = sizePx
                typeface = if (layer.bold) Typeface.create("sans-serif", Typeface.BOLD) else Typeface.create("sans-serif", Typeface.NORMAL)
                setShadowLayer(sizePx * 0.12f, 0f, sizePx * 0.06f, 0x99000000.toInt())
            }
            // StaticLayout handles Persian/Arabic shaping, bidirectional text and explicit line breaks.
            val layout = StaticLayout.Builder.obtain(layer.text, 0, layer.text.length, paint, base.width)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setTextDirection(TextDirectionHeuristics.FIRSTSTRONG_RTL)
                .setIncludePad(false)
                .setLineSpacing(sizePx * 0.12f, 1f)
                .build()
            val x = layer.x.coerceIn(0f, 1f) * base.width
            val y = layer.y.coerceIn(0f, 1f) * base.height
            canvas.save()
            canvas.translate(x - base.width / 2f, y - layout.height / 2f)
            layout.draw(canvas)
            canvas.restore()
        }
        return out
    }
}
