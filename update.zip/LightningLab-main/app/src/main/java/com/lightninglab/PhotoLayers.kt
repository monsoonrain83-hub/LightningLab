package com.lightninglab

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.RectF
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode

/** Brush mask strokes use normalized image coordinates; they remain editable until export. */
data class PhotoMaskStroke(val points: List<Pair<Float, Float>>, val radius: Float = 0.025f)

/** Non-destructive, independently editable photo overlay layer. Coordinates are normalized to canvas size. */
data class PhotoTextLayer(
    val id: Long,
    val name: String,
    val text: String,
    val x: Float = 0.5f,
    val y: Float = 0.5f,
    val size: Float = 0.075f,
    val color: Int = 0xFFFFFFFF.toInt(),
    val opacity: Float = 1f,
    val visible: Boolean = true,
    val bold: Boolean = true
)

data class PhotoImageLayer(
    val id: Long,
    val name: String,
    val bitmap: Bitmap,
    val x: Float = 0.5f,
    val y: Float = 0.5f,
    val width: Float = 0.35f,
    val opacity: Float = 1f,
    val visible: Boolean = true
)

data class PhotoShapeLayer(
    val id: Long,
    val name: String,
    val shape: Shape = Shape.RECTANGLE,
    val x: Float = 0.5f,
    val y: Float = 0.5f,
    val width: Float = 0.3f,
    val height: Float = 0.18f,
    val color: Int = 0xFFFFD43B.toInt(),
    val opacity: Float = 0.65f,
    val strokeWidth: Float = 0f,
    val visible: Boolean = true
) { enum class Shape { RECTANGLE, ELLIPSE } }

object PhotoLayers {
    /** Returns a new bitmap; input remains owned by caller. */
    fun render(base: Bitmap, layers: List<PhotoTextLayer>, shapes: List<PhotoShapeLayer> = emptyList(), images: List<PhotoImageLayer> = emptyList(), masks: List<PhotoMaskStroke> = emptyList()): Bitmap {
        if (layers.none { it.visible && it.text.isNotBlank() } && shapes.none { it.visible } && images.none { it.visible && !it.bitmap.isRecycled } && masks.isEmpty()) return base
        val out = base.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(out)
        if (masks.isNotEmpty()) {
            val erase = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR) }
            masks.forEach { stroke ->
                if (stroke.points.isNotEmpty()) {
                    val path = Path()
                    stroke.points.forEachIndexed { index, point ->
                        val x = point.first.coerceIn(0f, 1f) * base.width
                        val y = point.second.coerceIn(0f, 1f) * base.height
                        if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    val radius = (stroke.radius.coerceIn(0.003f, 0.18f) * base.width).coerceAtLeast(2f)
                    if (stroke.points.size == 1) canvas.drawCircle(stroke.points[0].first.coerceIn(0f, 1f) * base.width, stroke.points[0].second.coerceIn(0f, 1f) * base.height, radius, erase)
                    else {
                        val brush = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = radius * 2f; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR) }
                        canvas.drawPath(path, brush)
                    }
                }
            }
        }
        shapes.filter { it.visible }.forEach { layer ->
            val w = (base.width * layer.width.coerceIn(0.02f, 0.95f))
            val h = (base.height * layer.height.coerceIn(0.02f, 0.95f))
            val cx = layer.x.coerceIn(0f, 1f) * base.width
            val cy = layer.y.coerceIn(0f, 1f) * base.height
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = layer.color
                alpha = (255 * layer.opacity.coerceIn(0f, 1f)).toInt()
                style = if (layer.strokeWidth > 0f) Paint.Style.STROKE else Paint.Style.FILL
                strokeWidth = (base.width * layer.strokeWidth.coerceIn(0f, 0.04f)).coerceAtLeast(1f)
            }
            val rect = RectF(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
            when (layer.shape) {
                PhotoShapeLayer.Shape.RECTANGLE -> canvas.drawRect(rect, paint)
                PhotoShapeLayer.Shape.ELLIPSE -> canvas.drawOval(rect, paint)
            }
        }
        images.filter { it.visible && !it.bitmap.isRecycled }.forEach { layer ->
            val image = layer.bitmap
            val targetW = (base.width * layer.width.coerceIn(0.03f, 0.95f))
            val targetH = targetW * image.height.toFloat() / image.width.coerceAtLeast(1)
            val cx = layer.x.coerceIn(0f, 1f) * base.width
            val cy = layer.y.coerceIn(0f, 1f) * base.height
            val dst = RectF(cx - targetW / 2f, cy - targetH / 2f, cx + targetW / 2f, cy + targetH / 2f)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                alpha = (255 * layer.opacity.coerceIn(0f, 1f)).toInt()
            }
            canvas.drawBitmap(image, null, dst, paint)
        }
        layers.filter { it.visible && it.text.isNotBlank() }.forEach { layer ->
            val sizePx = (base.width * layer.size).coerceIn(12f, base.width * 0.3f)
            val paint = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
                color = layer.color
                alpha = (255 * layer.opacity.coerceIn(0f, 1f)).toInt()
                textSize = sizePx
                typeface = if (layer.bold) Typeface.create("sans-serif", Typeface.BOLD) else Typeface.create("sans-serif", Typeface.NORMAL)
                setShadowLayer(sizePx * 0.12f, 0f, sizePx * 0.06f, 0x99000000.toInt())
            }
            // StaticLayout handles Persian/Arabic shaping, bidirectional text and explicit line breaks.
            val layout = StaticLayout.Builder.obtain(layer.text, 0, layer.text.length, paint, base.width)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setTextDirection(TextDirectionHeuristics.FIRSTSTRONG_RTL)
                .setIncludePad(false)
                .setLineSpacing(sizePx * 0.12f, 1f)
                .build()
            val x = layer.x.coerceIn(0f, 1f) * base.width
            val y = layer.y.coerceIn(0f, 1f) * base.height
            canvas.save()
            canvas.translate(x - base.width / 2f, y - layout.height / 2f)
            layout.draw(canvas)
            canvas.restore()
        }
        return out
    }
}
