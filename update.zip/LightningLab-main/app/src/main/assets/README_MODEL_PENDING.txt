Bundled model asset contract
============================

The production model must be added here as:
  cloud_genus.tflite

Expected tensor contract (see CloudClassifier.kt):
  input:  [1, H, W, 3], float32 RGB, values 0..255
  output: [1, 11], float32 scores in CloudClassifier.LABELS order

MainVM.initModel() copies this asset into app-private storage automatically.
No user-facing model import is required.

IMPORTANT:
This source package intentionally does not contain third-party model weights until their
license and provenance are verified, or a model is trained from a dataset with explicit
reuse rights. Do not replace this notice with a fabricated/empty .tflite file.
