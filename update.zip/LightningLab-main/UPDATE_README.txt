LightningLab r12 update package

Upload this file's companion update.zip to the repository root using the existing GitHub workflow.
The workflow extracts update.zip, copies the project files into their normal paths, commits the applied update, and builds the debug APK.

This r12 snapshot refreshes the main dashboard, weather-analysis workspace and bottom navigation, and adds automatic loading of a bundled cloud model from app/src/main/assets/cloud_genus.tflite. It also adds a one-time GitHub Actions workflow that prepares the CC0 CCSN image subset, trains a single-photo model, validates its TFLite tensor contract, commits it into the app assets, and dispatches a new APK build.

IMPORTANT MODEL STATUS:
The update ZIP does not contain trained weights yet. After applying it, open Actions → Train embedded cloud model → Run workflow on main. The workflow will train from CC0 CCSN source images, add the TFLite model inside the Android app, and trigger Build APK. This can take a while on the hosted CPU runner. No fake or unlicensed third-party TFLite binary is included. See docs/WEATHER_AI_ROADMAP.md.

After upload:
1. Open the repository's Actions tab.
2. Open the newest Build APK run.
3. Wait for the run to finish successfully.
4. Download the LightningLab-debug-apk artifact.

If the build fails, share the first Kotlin/Gradle error beginning with 'e:' or the first 'What went wrong' section.
