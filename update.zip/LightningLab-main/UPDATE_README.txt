LightningLab update r10.36 (versionCode 46)

Major photo/video editor continuation:

PHOTO EDITOR
- Added editable photo-project persistence: original image, adjustment parameters (including HSL), text/shape/image layers, mask strokes and mask inversion are saved to app-private project storage.
- Imported image layers are copied into each project as PNG assets; loading restores editable layers rather than a flattened export.
- Added a photo-project browser with save, open and delete actions.

VIDEO EDITOR
- Added real decoded audio waveforms for imported music and recorded voice tracks. Waveform peaks are extracted from decoded PCM on an IO worker and rendered as separate MUSIC and VOICE lanes.
- Added editable timed IMAGE overlays with independent timeline clips, position/opacity keyframes and project-owned PNG assets.
- Added timed effect clips: selected colour filters can now be applied to a chosen interval instead of the entire video; effect clips are separate from the base filter setting.
- Export splits the timeline at image, effect and animation boundaries; opacity interpolates between keyframes and vertical anchor changes snap to the nearest keyframe.
- Video project codec upgraded to v3 and persists image assets, effect clips and keyframes while continuing to read v1/v2 projects.

VALIDATION
- Added unit tests for photo-project round trips, video overlay keyframe interpolation and v1 project compatibility.
- ZIP integrity can be checked after packaging. Android Gradle build and instrumentation/device playback tests were not run in this environment.


## r10.37 — تکمیل چرخش لایه‌ها و خروجی افکت‌ها
- چرخش مستقل متن، شکل و تصویر واردشده در ادیتور عکس (۱۸۰- تا ۱۸۰+ درجه).
- ذخیره چرخش در پروژه و بازیابی آن؛ پروژه‌های قدیمی با چرخش صفر باز می‌شوند.
- ذخیره اتمیک پروژه عکس در پوشه موقت و انتشار فقط پس از تکمیل همه فایل‌ها و manifest.
- در ادیتور ویدئو، افکت‌های زمان‌دار هم‌پوشان اکنون همگی به‌ترتیب شناسه اعمال می‌شوند؛ قبلاً فقط آخرین افکت فعال اعمال می‌شد.
- نسخه 1.0-r10.37 / versionCode 47.
