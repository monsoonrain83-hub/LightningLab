Lightning Lab — به‌روزرسانی یکپارچه فاز ۲.۱۷

این بسته سورس کامل پروژه است، نه APK آماده نصب. برای بیلد خودکار، فایل update.zip تولیدشده را در ریشه مخزن GitHub با همین نام بارگذاری کنید. workflow واحد build.yml آن را اعمال می‌کند، سورس را commit می‌کند، تست‌های واحد را اجرا می‌کند و APK آزمایشی را به‌عنوان Artifact در Actions قرار می‌دهد.

نسخه: 1.0-r10.17 (versionCode 27)

موارد حفظ‌شده: داشبورد Glassmorphism، ویرایشگر عکس، ویرایشگر ویدئو، تحلیل صاعقه، پایگاه دانش جوی آفلاین، و زیرساخت اختیاری TFLite برای تحلیل ابر و تفکیک هفت‌کلاسه پدیده‌های جوی.

محدودیت: هیچ مدل TFLite آموزش‌دیده‌ای در این سورس نیست. مدل‌های آموزش‌دیده باید جداگانه وارد برنامه شوند. حذف پس‌زمینه ML Kit ممکن است برای دریافت اولیه مدل به Google Play Services نیاز داشته باشد.

اعتبارسنجی این بسته: بررسی ساختار سورس، بررسی ZIP، XML و workflow؛ کامپایل Android و اجرای تست‌ها باید توسط GitHub Actions انجام شود.


PHASE 2.18: Added temporal consensus for cloud-genus candidates across sampled video frames. The video report now ranks recurring model candidates and displays frame support, frame share, mean raw score and peak raw score, with explicit non-calibrated-score caveats. Added unit tests for consensus, missing/invalid outputs and empty model results. Recycles the temporary classifier bitmap after pixel extraction. Version: 1.0-r10.18 (versionCode 28). Android Gradle build and device tests still require GitHub Actions/device verification.


PHASE 2.19: Added a transparent video cloud-cover trend summary based on sampled frames. It compares the mean cover estimate in the first and final thirds, reports the percentage-point change and observed range, and labels small changes as stable. Includes unit tests for increasing, decreasing, stable and insufficient-data cases. This is explicitly an image-derived proxy, not a meteorological cloud-cover observation; camera motion, exposure and non-sky pixels can bias it. Version: 1.0-r10.19 (versionCode 29).

Verification: ZIP integrity and source-level checks were performed. Android Gradle compilation and device tests were not run in this environment.
