Lightning Lab — بسته کامل به‌روزرسانی r10.34

این بسته سورس کامل پروژه است، نه APK آماده نصب. برای بیلد خودکار، فایل update.zip تولیدشده را در ریشه مخزن GitHub با همین نام بارگذاری کنید. workflow واحد build.yml آن را اعمال می‌کند، سورس را commit می‌کند، تست‌های واحد را اجرا می‌کند و APK آزمایشی را به‌عنوان Artifact در Actions قرار می‌دهد.

نسخه فعلی: 1.0-r10.34 (versionCode 44)

موارد حفظ‌شده: داشبورد Glassmorphism، ویرایشگر عکس، ویرایشگر ویدئو، تحلیل صاعقه، پایگاه دانش جوی آفلاین، و زیرساخت اختیاری TFLite برای تحلیل ابر و تفکیک هفت‌کلاسه پدیده‌های جوی.

محدودیت: هیچ مدل TFLite آموزش‌دیده‌ای در این سورس نیست. مدل‌های آموزش‌دیده باید جداگانه وارد برنامه شوند. حذف پس‌زمینه ML Kit ممکن است برای دریافت اولیه مدل به Google Play Services نیاز داشته باشد.

اعتبارسنجی این بسته: بررسی ساختار سورس، بررسی ZIP، XML و workflow؛ کامپایل Android و اجرای تست‌ها باید توسط GitHub Actions انجام شود.


PHASE 2.18: Added temporal consensus for cloud-genus candidates across sampled video frames. The video report now ranks recurring model candidates and displays frame support, frame share, mean raw score and peak raw score, with explicit non-calibrated-score caveats. Added unit tests for consensus, missing/invalid outputs and empty model results. Recycles the temporary classifier bitmap after pixel extraction. Version: 1.0-r10.18 (versionCode 28). Android Gradle build and device tests still require GitHub Actions/device verification.


PHASE 2.19: Added a transparent video cloud-cover trend summary based on sampled frames. It compares the mean cover estimate in the first and final thirds, reports the percentage-point change and observed range, and labels small changes as stable. Includes unit tests for increasing, decreasing, stable and insufficient-data cases. This is explicitly an image-derived proxy, not a meteorological cloud-cover observation; camera motion, exposure and non-sky pixels can bias it. Version: 1.0-r10.19 (versionCode 29).

Verification: ZIP integrity and source-level checks were performed. Android Gradle compilation and device tests were not run in this environment.

نسخه 1.0-r10.20 / versionCode 30:
- اتصال مدل اختیاری cloud_features.tflite به تحلیل آفلاین ویدئو.
- تجمیع زمانی ویژگی‌های ساختاری و نمایش پایداری و روند امتیاز خام.
- افزودن تست‌های واحد و مستندات فارسی فاز ۲.۲۰.
- برای تشخیص خودکار ویژگی‌ها باید مدل آموزش‌دیده و سازگار را از داخل برنامه وارد کنید؛ مدل آماده در این بسته موجود نیست.
- افزودن اشتراک‌گذاری گزارش متنی تحلیل ویدئو.
- امن‌ترشدن جایگزینی مدل ویژگی‌های ساختاری؛ مدل قبلی در صورت نامعتبر بودن فایل جدید بازیابی می‌شود.


نسخه 1.0-r10.21 / versionCode 31:
- بازطراحی بخش پایین ویرایشگر ویدئو با خط زمان چندلایه الهام‌گرفته از نمونه تصویری کاربر.
- مسیرهای مستقل و قابل انتخاب Video / Audio / Text / Sticker؛ قطعات ویدئو بر اساس مدت واقعی نمایش داده می‌شوند.
- مسیرهای خالی صوت، متن و استیکر به ابزار مرتبط هدایت می‌شوند.
- نوار صوتی صرفاً نشانگر مسیر است، نه waveform اندازه‌گیری‌شده.
- حفظ موتور خروجی Media3 و ابزارهای تدوین قبلی.

Phase 2.22: Cloud Atlas UI, offline taxonomy browsing, AICCA satellite-pattern reference, and repository/license/domain audit. Version 1.0-r10.22 (32). No new model weights included.

PHASE 2.25 / r10.25 — Compact cinematic video header
- Reduced home hero height from 264dp to 150dp.
- Replaced the static Canvas lightning illustration with both bundled reference clips in a muted looping Media3 playlist.
- Added lifecycle-aware pause/resume and player release.
- Added dark glass-friendly overlays and compact brand typography.
- Added Media3 ExoPlayer/UI and lifecycle-runtime-compose dependencies.
See docs/PHASE2_25_COMPACT_VIDEO_HEADER_FA.md.


PHASE 2.27 / r10.27 — Compact home header
- کاهش ارتفاع هدر ویدئویی از ۱۵۰ به ۱۲۴ dp.
- حفظ دو ویدئوی هدر، پخش چرخه‌ای بی‌صدا و مدیریت چرخه عمر پخش.
- حفظ الگوریتم تحلیل صاعقه، ابزارهای تدوین و تست‌های موجود.
- versionName: 1.0-r10.27 / versionCode: 37.
- کامپایل اندروید در این محیط اجرا نشده؛ نتیجه بیلد باید در GitHub Actions بررسی شود.

## r10.28 — Photo text-layer foundation
- Added a non-destructive photo text-layer stack, independent from global image adjustments.
- Add multiple text layers; toggle visibility; reorder; delete; and adjust size, horizontal/vertical position, opacity, and preset color.
- Text layers render in live preview and are included in PNG/JPEG export.
- Layer state is snapshotted before background rendering/export to avoid reading mutable UI state from worker threads.
- This is the first layer-stack milestone: image/mask/effect layer types and unified layer-aware undo/redo are still pending.


## r10.29 — Independent photo shape layers
- افزودن لایه‌های مستقل مستطیل و بیضی در ویرایشگر عکس.
- کنترل نمایش/مخفی‌سازی، عرض، ارتفاع، موقعیت افقی و عمودی، شفافیت و رنگ.
- ترکیب لایه‌های شکل در پیش‌نمایش زنده و خروجی نهایی؛ لایه‌های متن روی شکل‌ها رسم می‌شوند.
- لایه‌های تصویری/ماسک و تاریخچه یکپارچه Undo/Redo هنوز در مراحل بعدی هستند.
- versionName: 1.0-r10.29 / versionCode: 39.
- بیلد اندروید در این محیط اجرا نشده؛ GitHub Actions باید بررسی شود.


## r10.30 — Raster image overlay layers
- افزودن تصویر به‌عنوان لایه مستقل از گالری با Photo Picker اندروید.
- کنترل نمایش/مخفی‌سازی، ترتیب، اندازه، موقعیت، شفافیت و حذف لایه تصویر.
- ترکیب لایه‌های تصویری در پیش‌نمایش و خروجی نهایی.
- کوچک‌سازی تصویر لایه برای کاهش مصرف حافظه و آزادسازی Bitmap هنگام حذف یا پایان ViewModel.
- versionName: 1.0-r10.30 / versionCode: 40.
- بیلد اندروید در این محیط اجرا نشده؛ نتیجه باید در GitHub Actions بررسی شود.


## r10.31 — Editable local mask brush
- Added non-destructive local mask strokes with adjustable brush diameter.
- Mask strokes can be undone individually or cleared, and are included in live preview and exported image composition.
- Masking creates transparency; it is not AI object segmentation or content-aware reconstruction.

LightningLab r10.32 (versionCode 42): feathered photo masks, inverse mask mode, preview/export integration.


LightningLab r10.33 (versionCode 43):
- Unified photo editor undo/redo history now captures adjustments, text/shape/image layers, mask strokes and inverse-mask state in one chronological stack.
- Added feathered blending at the object-healing boundary to reduce hard circular repair seams.
- Selected text layers can now be edited in place and switched between bold and regular weight.
- Overlay image bitmaps remain valid for active undo snapshots and in-flight previews/exports when switching photos.
- Export now snapshots inverse-mask state before background rendering, preventing UI changes during export from altering the result.


## r10.34 — timed video overlay tracks
- Added independent timeline clips for text and stickers with persistent IDs, content, styling, start/end timestamps and track selection.
- Added timeline track blocks, clip deletion, start/end trimming sliders, and applying text/sticker edits to the selected clip.
- Video export now splits source segments at overlay boundaries and applies each text/sticker only during its active output interval, including reordered/trimmed source segments and speed changes.
- Project save/load now round-trips overlay track clips; older project files remain readable and legacy full-length text/sticker overlays still export when no timed clips exist.
- Added a ProjectCodec round-trip test covering multiple timed overlay clips.
- Android Gradle build/tests were not run in this environment (no Gradle executable or wrapper present).


## r10.35 — لایه‌بندی ترکیبی ویرایشگر عکس
- متن، شکل و تصویر واردشده اکنون در یک ترتیب سراسری (z-order) مشترک ترکیب می‌شوند؛ دیگر ترتیب رسم بر اساس نوع لایه ثابت نیست.
- دکمه‌های بالا/پایین هر لایه می‌توانند آن را نسبت به لایه‌های دیگر از هر نوع جابه‌جا کنند.
- پیش‌نمایش و خروجی نهایی دقیقاً از ترتیب یکسان استفاده می‌کنند.
- لایه جدید در بالاترین سطح قرار می‌گیرد و ترتیب لایه‌های قدیمی هنگام نیاز نرمال‌سازی می‌شود.
- ترتیب سراسری نیز در تاریخچه یکپارچه Undo/Redo ثبت می‌شود.
- نسخه: 1.0-r10.35 / versionCode 45.
- بیلد اندروید و تست‌ها در این محیط اجرا نشده‌اند؛ بررسی نهایی با GitHub Actions لازم است.
