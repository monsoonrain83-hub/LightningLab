# Lightning Lab — Offline Atmospheric Intelligence

Lightning Lab is an Android application built with Kotlin and Jetpack Compose. It combines lightning-video tools, photo/video editing, an offline atmospheric knowledge atlas, and optional on-device TensorFlow Lite analysis.

## Current source version

- `versionName`: `1.0-r10.23`
- `versionCode`: `33`
- Android `minSdk`: 29
- `compileSdk` / `targetSdk`: 34
- Java: 17

## Main areas

- Lightning detection and video analysis.
- Photo and video editing tools.
- Offline Cloud Atlas backed by the bundled SQLite knowledge database.
- Optional TFLite branches for WMO cloud genera, structural cloud features, binary cloud segmentation, and seven-class atmospheric segmentation.
- Temporal aggregation of model outputs for sampled video frames.

## Important model limitation

No trained `.tflite` weights are included in this source package. Until a model is trained on appropriately licensed, expert-reviewed data and imported into the app, model-based image classification is unavailable and fallback image heuristics must not be treated as validated meteorological observations. The Cloud Atlas is an offline reference encyclopedia, not an image classifier.

## Build

The repository includes `.github/workflows/build.yml`. Upload a complete project archive named `update.zip` to the repository root, or manually run the workflow. It applies the source update, runs `testDebugUnitTest`, builds the debug APK, and uploads the APK as a workflow artifact.

## Documentation

- `docs/PROJECT_STATUS.md` — actual source status and known limitations.
- `docs/WEATHER_AI_ARCHITECTURE.md` — model architecture.
- `docs/CLOUD_AI_REPOSITORY_REVIEW_FA.md` — review of external cloud-AI repositories.
- `docs/PHASE2_23_MODEL_IMPORT_SAFETY_FA.md` — latest code changes.
- `tools/cloud_ai/` — cloud-genus and structural-feature data/training tools.
- `tools/cloud_segmentation/` — segmentation datasets, annotation and training tools.


## Latest update — 1.0-r10.24

Model import recovery now restores the last known-good TFLite file after an interrupted or invalid replacement. See `docs/PHASE2_24_MODEL_RECOVERY_FA.md`. This is a reliability improvement; it does not add trained model weights.


## Latest update — 1.0-r10.27
- Reduced the video-backed home hero from 150dp to 124dp to give the main dashboard more room.
- Preserved both bundled storm clips, lifecycle-aware playback, the existing lightning analysis pipeline, editor tools, and unit tests.
- This source package does not include trained cloud-model weights. Android build/device verification must be performed by the repository workflow.

### r10.28 Photo layer foundation
The photo editor now supports independently editable text overlay layers with visibility, ordering, position, size, opacity, and color controls. Layers are composited in preview and export. Raster-image, mask, and effect layer types plus unified layer history remain future work.
