"""Validate the exact tensor contract consumed by CloudClassifier.kt."""
import argparse
import numpy as np
import tensorflow as tf

LABELS = ["Ac", "As", "Cb", "Cc", "Ci", "Cs", "Ct", "Cu", "Ns", "Sc", "St"]

p = argparse.ArgumentParser()
p.add_argument("--model", required=True)
a = p.parse_args()
interpreter = tf.lite.Interpreter(model_path=a.model, num_threads=2)
interpreter.allocate_tensors()
inp = interpreter.get_input_details()[0]
out = interpreter.get_output_details()[0]
shape = inp["shape"].tolist()
out_shape = out["shape"].tolist()
if len(shape) != 4 or shape[0] != 1 or shape[3] != 3 or inp["dtype"] != np.float32:
    raise SystemExit(f"Invalid input contract: shape={shape}, dtype={inp['dtype']}")
if len(out_shape) != 2 or out_shape[0] != 1 or out_shape[1] != len(LABELS) or out["dtype"] != np.float32:
    raise SystemExit(f"Invalid output contract: shape={out_shape}, dtype={out['dtype']}")
probe = np.full(shape, 127.0, dtype=np.float32)
interpreter.set_tensor(inp["index"], probe)
interpreter.invoke()
scores = interpreter.get_tensor(out["index"])
if not np.isfinite(scores).all():
    raise SystemExit("Model produced NaN/Inf on the validation probe")
print(f"TFLite contract OK: input={shape} float32 RGB 0..255; output={out_shape} float32")
print("Probe scores:", scores[0].tolist())
