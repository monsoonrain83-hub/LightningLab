"""Prepare the CCSN image subset from CloudBench for LightningLab training.

CloudBench is a retrieval benchmark. This script deliberately extracts only source
images whose row metadata identifies the CCSN Harvard Dataverse DOI and CC0 licence.
It ignores all other image sources and all query/relevance labels.

Install: pip install datasets pillow
Run:     python tools/prepare_cloudbench.py --out /tmp/lightninglab_ccsn
"""
import argparse
import csv
import hashlib
import os
import re
from collections import Counter
from io import BytesIO

from datasets import load_dataset
from PIL import Image

LABELS = ["Ac", "As", "Cb", "Cc", "Ci", "Cs", "Ct", "Cu", "Ns", "Sc", "St"]
CCSN_DOI = "10.7910/DVN/CADDPD"


def args_parse():
    p = argparse.ArgumentParser()
    p.add_argument("--out", required=True)
    p.add_argument("--dataset", default="sagecontinuum/CloudBench")
    p.add_argument("--split", default="train")
    return p.parse_args()


def decode_image(value):
    if value is None:
        return None
    if isinstance(value, Image.Image):
        return value
    if isinstance(value, dict):
        if value.get("bytes"):
            return Image.open(BytesIO(value["bytes"]))
        if value.get("path") and os.path.isfile(value["path"]):
            return Image.open(value["path"])
    return None


def image_class(image_id):
    if not isinstance(image_id, str):
        return None
    match = re.search(r"(?:^|/)ccsn/([A-Za-z]{2})/[^/]+$", image_id, re.IGNORECASE)
    if not match:
        return None
    code = match.group(1).upper()
    return code if code in LABELS else None


def main():
    args = args_parse()
    os.makedirs(args.out, exist_ok=True)
    print(f"Loading {args.dataset} [{args.split}] ...")
    ds = load_dataset(args.dataset, split=args.split)
    seen_ids, seen_hashes = set(), set()
    counts = Counter()
    manifest_rows = []

    for row in ds:
        image_id = row.get("image_id")
        code = image_class(image_id)
        if code is None or image_id in seen_ids:
            continue
        doi = str(row.get("doi", "")).lower()
        licence = str(row.get("license", "")).lower()
        # Fail closed: only the explicitly identified CCSN source images with CC0 terms.
        if CCSN_DOI not in doi or "cc0" not in licence:
            continue
        image = decode_image(row.get("image"))
        if image is None:
            continue
        try:
            image = image.convert("RGB")
            buffer = BytesIO()
            image.save(buffer, format="JPEG", quality=95, optimize=True)
            payload = buffer.getvalue()
            digest = hashlib.sha256(payload).hexdigest()
            if digest in seen_hashes:
                seen_ids.add(image_id)
                continue
            seen_hashes.add(digest)
            seen_ids.add(image_id)
            folder = os.path.join(args.out, code)
            os.makedirs(folder, exist_ok=True)
            filename = f"{digest[:16]}.jpg"
            with open(os.path.join(folder, filename), "wb") as f:
                f.write(payload)
            counts[code] += 1
            manifest_rows.append([image_id, code, licence, doi, digest])
        except Exception as exc:
            print(f"Skip {image_id}: {exc}")

    with open(os.path.join(args.out, "source_manifest.csv"), "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["image_id", "class", "source_license", "source_doi", "sha256"])
        writer.writerows(manifest_rows)

    print("Unique extracted source images by class:")
    for code in LABELS:
        print(f"  {code}: {counts[code]}")
    missing = [code for code in LABELS if counts[code] < 5]
    if missing:
        raise RuntimeError(
            "Insufficient CC0 CCSN images for classes: " + ", ".join(missing) +
            ". Do not silently train a reduced label set; inspect dataset metadata first."
        )
    print(f"Prepared {sum(counts.values())} unique images in {args.out}")


if __name__ == "__main__":
    main()
