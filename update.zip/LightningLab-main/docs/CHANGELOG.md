## r10.43
- Fixed Kotlin/JVM setter signature clashes by renaming explicit music and voice URI update methods.


## r10.32 — Feathered and inverse photo masks
- Added non-destructive feathered brush masks with adjustable softness.
- Added inverse mask mode for clearing the area outside painted strokes.
- Wired inverse-mask state into live preview and full-resolution export.
- Existing photo parameter Undo/Redo remains intact; mask strokes retain their dedicated undo/clear controls.
