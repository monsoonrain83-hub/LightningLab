# LightningLab visual system — r12

## Direction
A focused dark-weather workstation rather than a generic utility screen. The visual language uses deep navy surfaces, electric-yellow primary actions, cool atmospheric blue for secondary information, restrained green only for a ready/offline state, and clear typographic hierarchy. Persian/Arabic letter spacing remains zero to preserve joining.

## Main dashboard
- Full-bleed atmospheric lightning hero with gradient scrim and concise product identity.
- A single prominent lightning-detection workflow with sensitivity control and a strong primary action.
- Photo, video and weather tools are secondary destination cards with distinct icon containers and consistent spacing.
- Offline state is visible but does not dominate the screen.

## Weather workspace
- Dedicated atmospheric header with concise explanation and offline/photo-analysis markers.
- Clear upload-first flow; the selected sky image is shown in its own image panel.
- Results are grouped into image-derived indicators, AI model output, and observer review. This prevents heuristic image statistics from being confused with model classifications or human tags.
- Model scores use proportional bars and are explicitly called scores, not calibrated probabilities.
- The 10 natural WMO genera are offered for manual correction; CCSN's Ct contrail category is not exposed as a natural cloud genus.
- Species, varieties and supplementary features remain manual observer tags until separately trained and validated models exist.

## Global navigation
- Floating rounded dock, active-state pill, restrained animated color transition, readable labels and 48dp+ touch areas.
- Existing photo/video editing panels and workflows are preserved.

## Accessibility and scientific transparency
- Primary actions remain high contrast; status colors are not used as decoration.
- The UI never describes the current heuristic cover/texture estimate as a validated WMO observation.
- An absent model is shown as a fallback state, not as a working AI classifier.
