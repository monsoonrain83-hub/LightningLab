package com.lightninglab

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ProjectCodecTest {
    private fun sample() = ProjectData(
        "Project 10-30", "main.mp4", 7000L, listOf(SegData(0, 2000, null), SegData(500, 1500, "clip_1.mp4")),
        "music.wav", null, true, 3, 0.5f, 0.2f, -0.1f, 90, true, false, 1.7777f,
        "Hello \u06a9\u0644\u0627\u0633", -16777216, 2, 0, true, "\u26a1", 1, 2, 0.5f, 1.5f, 0.25f,
        listOf(OverlayClipData(7L, "TEXT", "Rain alert", 1200L, 4200L, -1, 2, 0, true, 450L, 700L),
            OverlayClipData(8L, "STICKER", "⚡", 5000L, 6500L, -1, 1, 2, false)))

    @Test fun roundTripKeepsEverything() {
        val p = sample()
        assertEquals(p, ProjectCodec.decode(ProjectCodec.encode(p)))
    }

    @Test fun oldOverlayProjectsDecodeWithZeroFadeDefaults() {
        val legacy = ProjectCodec.encode(sample()).replace("\"fi\":450,\"fo\":700", "")
        val decoded = ProjectCodec.decode(legacy)!!
        assertEquals(0L, decoded.overlayClips.first().fadeInMs)
        assertEquals(0L, decoded.overlayClips.first().fadeOutMs)
    }

    @Test fun corruptOrUnknownVersionIsRejected() {
        assertNull(ProjectCodec.decode("not json"))
        assertNull(ProjectCodec.decode("{\"v\":99,\"name\":\"x\"}"))
    }
}
