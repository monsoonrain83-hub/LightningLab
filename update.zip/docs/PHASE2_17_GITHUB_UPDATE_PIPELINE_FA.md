# فاز ۲.۱۷ — بستهٔ به‌روزرسانی یک‌فایلی و بیلد خودکار

## روش استفاده
فایل `update.zip` را در ریشهٔ مخزن GitHub آپلود و Commit کنید. Workflow واحد
`.github/workflows/build.yml` با تغییر همین فایل فعال می‌شود.

Workflow:
1. مسیرهای ZIP را برای جلوگیری از استخراج ناامن بررسی می‌کند.
2. ریشهٔ پروژه را با `settings.gradle.kts` پیدا می‌کند.
3. فایل‌های بسته را روی مخزن اعمال می‌کند.
4. Workflowهای تکراری را حذف می‌کند.
5. `update.zip` را از مخزن حذف و تغییرات سورس را Commit/Push می‌کند.
6. Java 17، Gradle 8.7 و Android SDK 34 را آماده می‌کند.
7. تست‌های واحد و `assembleDebug` را اجرا می‌کند.
8. APK را با نام Artifact برابر `LightningLab-debug-apk` منتشر می‌کند.

## تنظیم لازم در GitHub
در Settings → Actions → General → Workflow permissions، اجازهٔ Read and write
برای GITHUB_TOKEN فعال باشد. اگر شاخهٔ اصلی Protected است، باید اجازهٔ Push برای
GitHub Actions فراهم شود؛ در غیر این صورت مرحلهٔ ثبت سورس ممکن است شکست بخورد.

## محدودیت‌ها
این محیط محلی Android SDK/Gradle کامل ندارد؛ بنابراین بیلد واقعی فقط در GitHub Actions
قابل تأیید است. موفقیت Workflow را باید در تب Actions بررسی کرد. وجود Artifact APK
به‌تنهایی تا قبل از نصب و آزمایش روی گوشی، تأیید عملکرد دستگاهی نیست.
