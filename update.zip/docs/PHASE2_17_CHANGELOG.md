# Phase 2.17 changelog

- Added a single GitHub Actions workflow for root-level `update.zip` uploads.
- Workflow validates archive paths before extraction.
- Applies the update overlay to the checked-out repository.
- Removes duplicate workflow definitions and deletes the consumed update.zip.
- Commits applied source changes back to the branch.
- Runs unit tests and builds the debug APK with Java 17, Gradle 8.7 and Android SDK 34.
- Uploads the APK artifact and diagnostic reports on failure.
- Bumped Android version to 1.0-r10.17 / versionCode 27.
