Lightning Lab — Phase 2.17
Version: 1.0-r10.17 (versionCode 27)

This source package is delivered as update.zip for the repository-root update workflow.

How to update:
1. Upload this exact update.zip file to the ROOT of the GitHub repository.
2. Commit the upload to the default branch (main/master).
3. GitHub Actions runs the single workflow at .github/workflows/build.yml.
4. The workflow safely extracts the update, applies files to the repository, removes update.zip,
   commits the applied source, runs unit tests and builds the debug APK.
5. Download LightningLab-debug-apk from the successful Actions run's Artifacts section.

Important:
- Do not upload the extracted contents manually when using this update.zip workflow.
- The first upload may also start an older workflow that already exists on the remote repository.
  This package removes the duplicate workflow after it is applied. Subsequent updates use one workflow.
- GitHub repository Settings > Actions > General should allow the GITHUB_TOKEN to have read and
  write permissions. Branch protection must permit the Actions bot to push updates. If push-back
  is blocked, the workflow still attempts the APK build, but the applied source will not persist
  in the repository until write permissions are fixed.
- The APK is produced only if Gradle compilation and unit tests pass.
- No trained cloud segmentation weights are included. The offline inference pipeline requires
  compatible TFLite model files trained separately.
- This package has not been compiled in this environment. The GitHub Actions run is the first
  full Android build verification for this source state.
